from pathlib import Path
import hashlib, json, shutil, tarfile
root = Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud')
archive_path = Path('/tmp/vidur-send-recv-20260930.tar.gz')
backup = Path('/home/turbo_ops/changle/Files/vidur_send_recv_sync_backups/20260930_send_recv_60')
with tarfile.open(archive_path) as archive:
    manifest = json.load(archive.extractfile('manifest.json'))
    payload = {}
    for rel, hashes in manifest.items():
        relative = Path(rel)
        assert not relative.is_absolute() and '..' not in relative.parts
        dest = root / relative
        current = hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None
        if current != hashes['before']:
            raise RuntimeError('Remote file changed since inspection: ' + rel)
        data = archive.extractfile(rel).read()
        assert hashlib.sha256(data).hexdigest() == hashes['after']
        payload[rel] = data
    backup.mkdir(parents=True, exist_ok=False)
    for rel in payload:
        dest = root / rel
        if dest.exists():
            saved = backup / rel
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, saved)
    for rel, data in payload.items():
        dest = root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        temp = dest.with_name(dest.name + '.send_recv_sync')
        temp.write_bytes(data)
        if dest.exists():
            shutil.copymode(dest, temp)
        temp.replace(dest)
        assert hashlib.sha256(dest.read_bytes()).hexdigest() == manifest[rel]['after']
        print('Verified: ' + rel)
    shutil.copy2(archive_path, backup / archive_path.name)
print('Backup: ' + str(backup))
